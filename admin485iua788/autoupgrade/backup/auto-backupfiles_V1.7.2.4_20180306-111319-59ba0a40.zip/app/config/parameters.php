<?php return array (
  'parameters' => 
  array (
    'database_host' => '127.0.0.1',
    'database_port' => '',
    'database_name' => 'prestashop',
    'database_user' => 'admin',
    'database_password' => 'azerty123',
    'database_prefix' => 'ps_',
    'database_engine' => 'InnoDB',
    'mailer_transport' => 'smtp',
    'mailer_host' => '127.0.0.1',
    'mailer_user' => NULL,
    'mailer_password' => NULL,
    'secret' => 'PCUJcZtKbb1pMBHmFCdFRiYpjFFVGTEuPCqfsj7aBnCGmXFVYZmW20ms',
    'ps_caching' => 'CacheMemcache',
    'ps_cache_enable' => false,
    'ps_creation_date' => '2018-02-13',
    'locale' => 'fr-FR',
    'cookie_key' => 'mEijnsFL6Qapc2rnUY1dNFaFnNXOct6MNKNaimFjW7omIaMLUXbd5Ef3',
    'cookie_iv' => 'Jsfffs5Q',
    'new_cookie_key' => 'def00000a2e4f4d0167760049b487fcf74fe48d1f2406d726fefd1af39b370cb32aa8d315a5e307b04bee6b663075930fc5f4105d0468416680eb8d9973b5f84ddbd4ffa',
  ),
);
